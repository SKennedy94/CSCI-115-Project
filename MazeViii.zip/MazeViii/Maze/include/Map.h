#ifndef MAP_H
#define MAP_H


class Map
{
    public:
        Map();
        virtual ~Map();

    protected:

    private:
};

#endif // MAP_H
